package Se.kth.iv1350.Project1PointOfSale.integration;

/**
 * The class printer to prints out the receipt.
 */
public class Printer {
    public Printer(){ }

    /**
     * This method to print out the receipt.
     * @param receipt
     */

    public static void printOutTheReceipt(String receipt){

        System.out.println(receipt.toString());
    }
}