package Se.kth.iv1350.Project1PointOfSale.view;

import Se.kth.iv1350.Project1PointOfSale.model.CurrentSaleObserver;

public class TotalRevenueView extends CurrentSaleObserver {

}

