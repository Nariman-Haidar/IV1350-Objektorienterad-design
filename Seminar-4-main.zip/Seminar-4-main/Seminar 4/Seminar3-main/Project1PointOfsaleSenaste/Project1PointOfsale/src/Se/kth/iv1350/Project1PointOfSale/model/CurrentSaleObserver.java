package Se.kth.iv1350.Project1PointOfSale.model;
/*
this class to created en object that registered with the items that be saled
 */
public class CurrentSaleObserver {
    void updateTotalRevenue(double totalprice) {

    }
}
